
export default () => {
    const div = document.createElement('div');
    const divContent = `
    <div class="buttonsOfCategories">
    <button>Inteligencia artificial</button>
    <button>Realidad virtual</button>
    <button>Robótica</button>
    <button>Ciberseguridad</button>
    <button>Dispositivos móviles</button>
    <button>Curiosidades(ciencias)</button>
</div>
<div class="section-of-new-post">
<form class="form-post">
<label class="crear-post-text" for="post">Crear un nuevo post</label>
<input type="text" name="post" placeholder="¿Que estás pensando?"></input>
<button class="button-publicar-post">Publicar</button>
</form>
</div>
<div class="container-of-posts>
<h6 class="post-tittle-categoria">Categoría<h6>
<h7 class="tittle-of-post">Titulo</h7>
<p>DESCRIPCION</p>
<button class="like"><3</button>
<button class="coment">comment</button>
<button class="share">share</button>
</div>`;
div.innerHTML=divContent;
return div;
}